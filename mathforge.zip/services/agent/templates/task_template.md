# Task Template: Explore _{Subdomain}_

**Research Task for:** _{Subdomain}_

**Description:**  
- Review current literature and results related to _{Subdomain}_.
- Identify any existing barriers (e.g., oracle separations, natural proofs issues).
- Provide a summary of findings along with references.

**Deliverables:**  
- Written report (Markdown/PDF)
- Code snippets (if applicable)
- References to published papers

**Labels:**  
- decomposition  
- research  
- P vs NP

**Assignees:**  
- [ ] (unassigned)